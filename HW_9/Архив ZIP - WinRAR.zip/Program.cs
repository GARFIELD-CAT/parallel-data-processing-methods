using System;
using System.Collections.Generic;
using System.Diagnostics;
using System.Threading;
using System.Threading.Tasks.Dataflow;

namespace DataflowApp;

/// <summary>
/// Точка входа.
///
/// Что делает программа:
///   1. Генерирует 100 000 котировок (с фиксированным seed = 42 для воспроизводимости).
///   2. Прогоняет простой, сложный и broadcast-пайплайн.
///   3. Прогоняет пайплайн обработки котировок (фильтр -> SMA -> сигнал -> "БД").
///   4. Сравнивает производительность Dataflow и последовательной обработки.
///   5. Демонстрирует throttled/prioritized пайплайны и пользовательские блоки.
///   6. Печатает сводную статистику и проверяет корректность.
/// </summary>
internal static class Program
{
    private const int QuoteCount = 100_000;
    private static readonly string[] Symbols = { "AAPL", "GOOGL", "MSFT", "AMZN", "TSLA" };

    private static void Main()
    {
        // Поддержка UTF-8 в консоли (для русских символов).
        Console.OutputEncoding = System.Text.Encoding.UTF8;

        try
        {
            Console.WriteLine("=== TPL Dataflow: тестирование ===");
            Console.WriteLine();

            // 1. Генерация тестовых данных.
            Console.Write("Генерация тестовых котировок... ");
            var quotes = GenerateTestQuotes(QuoteCount);
            Console.WriteLine($"готово ({quotes.Count:N0} котировок).");
            Console.WriteLine();

            var pipeline = new DataflowPipeline();
            var benchmark = new DataflowBenchmark();

            // 2. Простой пайплайн (CPU-bound обработка, параллельная).
            var simpleHandle = pipeline.BuildSimplePipeline();
            var simpleSw = Stopwatch.StartNew();
            for (int i = 0; i < QuoteCount; i++) simpleHandle.Input.Post(i);
            simpleHandle.Input.Complete();
            simpleHandle.Completion.Wait();
            simpleSw.Stop();
            double simpleThroughput = QuoteCount / Math.Max(simpleSw.Elapsed.TotalSeconds, 0.0001);

            // 3. Сложный пайплайн с ветвлениями.
            var complexHandle = pipeline.BuildComplexPipeline();
            var complexSw = Stopwatch.StartNew();
            for (int i = 0; i < QuoteCount; i++) complexHandle.Input.Post(i);
            complexHandle.Input.Complete();
            complexHandle.Completion.Wait();
            complexSw.Stop();

            // 4. Broadcast-пайплайн (одно сообщение -> трём получателям).
            var broadcastHandle = pipeline.BuildBroadcastPipeline();
            for (int i = 0; i < 1000; i++) broadcastHandle.Input.Post(i);
            broadcastHandle.Input.Complete();
            broadcastHandle.Completion.Wait();

            // 5. Пайплайн обработки рыночных данных.
            var marketProcessor = new MarketDataProcessor(movingAveragePeriod: 5);
            var tradingHandle = marketProcessor.BuildTradingPipeline();
            var tradingSw = Stopwatch.StartNew();
            foreach (var quote in quotes) tradingHandle.Input.Post(quote);
            tradingHandle.Input.Complete();
            tradingHandle.Completion.Wait();
            tradingSw.Stop();

            int signalsGenerated = tradingHandle.GetSignalsCount();
            int tradingErrors = tradingHandle.GetErrorCount();
            bool calcCorrect = CheckMovingAverageCorrectness(marketProcessor);

            // 6. Последовательная обработка той же нагрузки — для сравнения в сводке.
            var sequential = benchmark.BenchmarkSequentialProcessing(QuoteCount);
            double dataflowVsSequential =
                sequential.ElapsedMs / Math.Max((double)simpleSw.ElapsedMilliseconds, 0.0001);

            // 7. Сводная статистика (формат ТЗ).
            Console.WriteLine("=== Результаты тестирования TPL Dataflow ===");
            Console.WriteLine();

            Console.WriteLine("Простой пайплайн:");
            Console.WriteLine($"  Количество сообщений: {QuoteCount:N0}");
            Console.WriteLine($"  Время выполнения: {simpleSw.ElapsedMilliseconds} мс");
            Console.WriteLine($"  Пропускная способность: {simpleThroughput:N0} сообщений/сек");
            Console.WriteLine($"  Обработанные сообщения: {simpleHandle.GetProcessedCount():N0}");
            Console.WriteLine();

            Console.WriteLine("Сложный пайплайн:");
            Console.WriteLine($"  Количество сообщений: {QuoteCount:N0}");
            Console.WriteLine($"  Время выполнения: {complexSw.ElapsedMilliseconds} мс");
            Console.WriteLine($"  Пропускная способность: {QuoteCount / Math.Max(complexSw.Elapsed.TotalSeconds, 0.0001):N0} сообщений/сек");
            Console.WriteLine($"  Обработанные сообщения: {complexHandle.GetProcessedCount():N0}");
            Console.WriteLine();

            Console.WriteLine("Broadcast пайплайн:");
            Console.WriteLine($"  Получателей: 3, сообщений на каждого: 1,000");
            Console.WriteLine($"  Всего записей обработано: {broadcastHandle.GetProcessedCount():N0}");
            Console.WriteLine();

            Console.WriteLine("Пайплайн обработки торговых данных:");
            Console.WriteLine($"  Количество котировок: {QuoteCount:N0}");
            Console.WriteLine($"  Время выполнения: {tradingSw.ElapsedMilliseconds} мс");
            Console.WriteLine($"  Сгенерировано сигналов: {signalsGenerated:N0}");
            Console.WriteLine($"  Корректность расчетов: {(calcCorrect ? "Да" : "Нет")}");
            Console.WriteLine();

            Console.WriteLine("Сравнение производительности:");
            Console.WriteLine($"  Dataflow vs Последовательная: {dataflowVsSequential:F2}x");
            Console.WriteLine($"  Пропускная способность: {simpleThroughput:N0} сообщений/сек");
            Console.WriteLine();

            // 8. Полное сравнение всех подходов (второй шаблон ТЗ).
            benchmark.CompareAllApproaches(QuoteCount);
            Console.WriteLine();

            // 9. Демонстрация throttled / prioritized пайплайнов.
            DemonstrateAdvancedPipelines();

            // 10. Демонстрация пользовательских блоков (в т.ч. обработка ошибок).
            DemonstrateCustomBlocks();

            // 11. Проверка корректности.
            bool allOk =
                simpleHandle.GetProcessedCount() == QuoteCount &&
                complexHandle.GetProcessedCount() == QuoteCount &&
                signalsGenerated == quotes.Count &&   // все сгенерированные котировки валидны
                tradingErrors == 0 &&
                calcCorrect;

            Console.WriteLine(allOk
                ? "Проверка: все сообщения обработаны корректно. Проблем не обнаружено."
                : "Проверка: обнаружены расхождения (см. счётчики выше).");

            Console.WriteLine();
            Console.WriteLine("Готово.");
        }
        catch (Exception ex)
        {
            Console.Error.WriteLine($"Ошибка во время выполнения: {ex.Message}");
        }
    }

    /// <summary>
    /// Сгенерировать список котировок с фиксированным seed (42) — для воспроизводимости.
    /// </summary>
    private static List<Quote> GenerateTestQuotes(int count)
    {
        var random = new Random(42);
        var quotes = new List<Quote>(count);
        var startTime = DateTime.UtcNow;

        for (int i = 0; i < count; i++)
        {
            quotes.Add(new Quote
            {
                Symbol = Symbols[random.Next(Symbols.Length)],
                Price = 50m + (decimal)(random.NextDouble() * 950.0),
                Volume = random.Next(100, 1_000_001),
                Timestamp = startTime.AddMilliseconds(i),
                QuoteType = random.Next(2) == 0 ? "BID" : "ASK"
            });
        }

        return quotes;
    }

    /// <summary>
    /// Проверка корректности расчёта SMA на синтетических данных.
    /// Для цен [10, 20, 30, 40, 50] и периода 5 SMA = 30.
    /// </summary>
    private static bool CheckMovingAverageCorrectness(MarketDataProcessor processor)
    {
        var prices = new List<decimal> { 10m, 20m, 30m, 40m, 50m };
        decimal sma = processor.CalculateMovingAverage(prices, 5);
        return sma == 30m;
    }

    /// <summary>
    /// Демонстрация пайплайнов с ограничением буфера и приоритезацией.
    /// </summary>
    private static void DemonstrateAdvancedPipelines()
    {
        Console.WriteLine("=== Демонстрация throttled и prioritized пайплайнов ===");
        var pipeline = new DataflowPipeline();

        // Throttled: ограниченный буфер. Подаём через SendAsync, чтобы при
        // переполнении НЕ терять сообщения (Post вернул бы false), а ждать места.
        const int throttledMessages = 5_000;
        var throttled = pipeline.BuildThrottledPipeline(maxMessages: 64);
        for (int i = 0; i < throttledMessages; i++)
            throttled.Input.SendAsync(i).Wait(); // backpressure: ждём свободное место
        throttled.Input.Complete();
        throttled.Completion.Wait();
        Console.WriteLine($"  Throttled (буфер 64): отправлено {throttledMessages:N0}, " +
                          $"обработано {throttled.GetProcessedCount():N0}");

        // Prioritized: два входа. Кладём поровну; высокоприоритетный связан первым.
        var prioritized = pipeline.BuildPrioritizedPipeline();
        for (int i = 0; i < 1_000; i++)
        {
            prioritized.LowPriorityInput.Post($"LOW:{i}");
            prioritized.HighPriorityInput.Post($"HIGH:{i}");
        }
        prioritized.HighPriorityInput.Complete();
        prioritized.LowPriorityInput.Complete();
        prioritized.Completion.Wait();
        Console.WriteLine($"  Prioritized: высокий приоритет — {prioritized.GetHighProcessed():N0}, " +
                          $"низкий — {prioritized.GetLowProcessed():N0}");
        Console.WriteLine();
    }

    /// <summary>
    /// Демонстрация пользовательских блоков из DataflowBlocks.cs.
    /// </summary>
    private static void DemonstrateCustomBlocks()
    {
        Console.WriteLine("=== Демонстрация пользовательских блоков ===");
        var propagate = new DataflowLinkOptions { PropagateCompletion = true };

        // 1) FilterBlock: пропускаем только чётные числа.
        int evenCount = 0;
        var filter = new FilterBlock<int>(n => n % 2 == 0);
        var evenSink = new ActionBlock<int>(_ => Interlocked.Increment(ref evenCount));
        filter.LinkTo(evenSink, propagate);
        for (int i = 0; i < 10; i++) filter.Post(i);
        filter.Complete();
        evenSink.Completion.Wait();
        Console.WriteLine($"  FilterBlock: из 10 чисел прошло чётных — {evenCount}");

        // 2) BatchBlock: группируем по 4; остаток выталкиваем TriggerBatch().
        int batchCount = 0;
        var batch = new BatchBlock<int>(4);
        var batchSink = new ActionBlock<int[]>(_ => Interlocked.Increment(ref batchCount));
        batch.LinkTo(batchSink, propagate);
        for (int i = 0; i < 10; i++) batch.Post(i);
        batch.TriggerBatch(); // вытолкнуть остаток (10 = 4 + 4 + 2)
        batch.Complete();
        batchSink.Completion.Wait();
        Console.WriteLine($"  BatchBlock: 10 элементов по 4 -> пачек: {batchCount}");

        // 3) AggregatorBlock: копим во временное окно и закрываем его.
        int windowItems = 0;
        var aggregator = new AggregatorBlock<int>(TimeSpan.FromSeconds(1));
        var windowSink = new ActionBlock<List<int>>(w => Interlocked.Add(ref windowItems, w.Count));
        aggregator.Source.LinkTo(windowSink, propagate);
        for (int i = 0; i < 5; i++) aggregator.Add(i);
        aggregator.CompleteWindow();
        aggregator.Complete();
        windowSink.Completion.Wait();
        Console.WriteLine($"  AggregatorBlock: элементов в закрытом окне — {windowItems}");

        // 4) ErrorHandlingBlock: намеренно бросаем исключение на одном элементе.
        int handledErrors = 0;
        var errorBlock = new ErrorHandlingBlock<int>(
            workItem: n => { if (n == 3) throw new InvalidOperationException("плохой элемент"); },
            errorHandler: _ => Interlocked.Increment(ref handledErrors));
        for (int i = 0; i < 5; i++) errorBlock.Post(i);
        errorBlock.Complete();
        errorBlock.Completion.Wait();
        Console.WriteLine($"  ErrorHandlingBlock: перехвачено ошибок — {handledErrors} (пайплайн не упал)");
        Console.WriteLine();
    }
}
