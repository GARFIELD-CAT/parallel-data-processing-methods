using System;
using System.Collections.Generic;
using System.Threading;
using System.Threading.Tasks;
using System.Threading.Tasks.Dataflow;

namespace DataflowApp;

/// <summary>
/// Класс, демонстрирующий разные способы построения пайплайнов TPL Dataflow.
///
/// Каждый метод Build*** возвращает объект <see cref="PipelineHandle{T}"/>,
/// в котором лежит:
///   - Input:           блок, куда нужно отправлять сообщения (точка входа);
///   - Completion:      задача, по которой можно дождаться полного завершения;
///   - GetProcessedCount: функция, возвращающая количество обработанных сообщений.
///
/// Такая обёртка нужна, чтобы вызывающий код (Program / Benchmark)
/// не знал о внутреннем устройстве пайплайна — только об интерфейсе.
/// </summary>
public class DataflowPipeline
{
    /// <summary>Количество итераций «тяжёлой» обработки одного сообщения.</summary>
    public const int HeavyWorkIterations = 1500;

    /// <summary>
    /// Имитация CPU-bound обработки одного сообщения.
    /// Чистая детерминированная функция — используется и в Dataflow-пайплайне,
    /// и в последовательном бенчмарке, чтобы сравнение производительности было честным.
    /// Именно на такой «тяжёлой» нагрузке Dataflow обгоняет однопоточную обработку.
    /// </summary>
    public static int HeavyTransform(int value)
    {
        int result = value;
        for (int i = 0; i < HeavyWorkIterations; i++)
            result = (result * 31 + 17) % 1_000_003;
        return result;
    }

    /// <summary>
    /// Удобная обёртка для возврата пайплайна "наружу".
    /// T — это тип сообщения, которое принимает пайплайн на входе.
    /// </summary>
    public class PipelineHandle<T>
    {
        /// <summary>Точка входа: сюда отправляем сообщения через Post или SendAsync.</summary>
        public required ITargetBlock<T> Input { get; init; }

        /// <summary>Задача завершения всего пайплайна (когда обработаны все сообщения).</summary>
        public required Task Completion { get; init; }

        /// <summary>Возвращает количество обработанных сообщений (на момент вызова).</summary>
        public required Func<int> GetProcessedCount { get; init; }
    }

    // =============================================================
    // 1. ПРОСТОЙ ПАЙПЛАЙН: BufferBlock -> TransformBlock -> ActionBlock
    // =============================================================

    /// <summary>
    /// Простой линейный пайплайн из 3 блоков:
    ///
    ///    [BufferBlock] --> [TransformBlock] --> [ActionBlock]
    ///       вход            обработка             приёмник
    ///
    /// Обработка — CPU-bound (<see cref="HeavyTransform"/>), а TransformBlock
    /// настроен на параллелизм (MaxDegreeOfParallelism), поэтому на тяжёлой
    /// нагрузке пайплайн использует все ядра и обгоняет последовательный код.
    /// ActionBlock считает обработанные сообщения.
    /// </summary>
    public PipelineHandle<int> BuildSimplePipeline()
    {
        // Счётчики. Локальные переменные, захваченные замыканием — C# превращает
        // их в поля скрытого класса, поэтому Interlocked к ним применим.
        int processedCount = 0;
        int errorCount = 0;

        // 1. Источник: входной буфер.
        var bufferBlock = new BufferBlock<int>();

        // 2. Преобразование. Лямбда СИНХРОННАЯ (никаких async/await внутри блока).
        //    Тело обёрнуто в try/catch — ошибка одного сообщения не роняет пайплайн.
        var transformBlock = new TransformBlock<int, int>(item =>
        {
            try
            {
                return HeavyTransform(item);
            }
            catch
            {
                Interlocked.Increment(ref errorCount);
                return 0; // нейтральное значение — сообщение не теряем
            }
        },
        new ExecutionDataflowBlockOptions
        {
            // Распараллеливаем тяжёлую обработку по всем ядрам.
            MaxDegreeOfParallelism = Environment.ProcessorCount,
            // Порядок для подсчёта не важен — отключаем ради пропускной способности.
            EnsureOrdered = false
        });

        // 3. Приёмник: атомарно увеличивает счётчик.
        var actionBlock = new ActionBlock<int>(_ =>
        {
            Interlocked.Increment(ref processedCount);
        });

        // PropagateCompletion = true: Complete() источника каскадом завершит цепочку.
        var linkOptions = new DataflowLinkOptions { PropagateCompletion = true };

        bufferBlock.LinkTo(transformBlock, linkOptions);
        transformBlock.LinkTo(actionBlock, linkOptions);

        return new PipelineHandle<int>
        {
            Input = bufferBlock,
            Completion = actionBlock.Completion,
            GetProcessedCount = () => processedCount
        };
    }

    // =============================================================
    // 2. СЛОЖНЫЙ ПАЙПЛАЙН С ВЕТВЛЕНИЯМИ И ОБЪЕДИНЕНИЕМ
    // =============================================================

    /// <summary>
    /// Пайплайн с ветвлением по предикату:
    ///
    ///                  [BufferBlock] (вход)
    ///                        |
    ///                  [Math.Abs]          (нормализация)
    ///                        |
    ///                 +------+------+
    ///                 |             |
    ///         (чётные)        (нечётные)
    ///             |                 |
    ///        [квадрат]         [умножить на 3]
    ///             |                 |
    ///             +------+----------+
    ///                    |
    ///               [ActionBlock]     (общий приёмник)
    ///
    /// При ветвлении нельзя включать PropagateCompletion на обеих ветках —
    /// первая же завершившаяся ветка закроет приёмник, и вторая упадёт.
    /// Поэтому завершением управляем вручную (см. локальную функцию ниже).
    /// </summary>
    public PipelineHandle<int> BuildComplexPipeline()
    {
        int processedCount = 0;

        var inputBuffer = new BufferBlock<int>();

        // Нормализация: абсолютное значение. MaxDegreeOfParallelism позволяет
        // блоку обрабатывать несколько сообщений параллельно.
        var absBlock = new TransformBlock<int, int>(
            item => { try { return Math.Abs(item); } catch { return 0; } },
            new ExecutionDataflowBlockOptions
            {
                MaxDegreeOfParallelism = Environment.ProcessorCount
            });

        var evenBranch = new TransformBlock<int, int>(
            item => { try { return item * item; } catch { return 0; } });

        var oddBranch = new TransformBlock<int, int>(
            item => { try { return item * 3; } catch { return 0; } });

        var sinkBlock = new ActionBlock<int>(_ => Interlocked.Increment(ref processedCount));

        var propagate = new DataflowLinkOptions { PropagateCompletion = true };

        // inputBuffer -> absBlock: с автозавершением.
        inputBuffer.LinkTo(absBlock, propagate);

        // Из absBlock — два LinkTo с разными ПРЕДИКАТАМИ.
        absBlock.LinkTo(evenBranch, item => item % 2 == 0);
        absBlock.LinkTo(oddBranch, item => item % 2 != 0);

        // Заглушка на случай, если ни один предикат не сработает (для int не бывает,
        // но в общем случае спасает сообщения от подвисания в буфере).
        absBlock.LinkTo(DataflowBlock.NullTarget<int>());

        // Из веток — в общий приёмник. БЕЗ PropagateCompletion (см. комментарий выше).
        evenBranch.LinkTo(sinkBlock);
        oddBranch.LinkTo(sinkBlock);

        // Завершение через локальную async-функцию: это ОРКЕСТРАЦИЯ завершения,
        // а не распараллеливание данных. async/await тут допустим — он не внутри
        // блока обработки. Никаких ContinueWith(...).Wait(), блокирующих поток пула.
        async Task CompleteWhenDone()
        {
            await absBlock.Completion;            // дождались нормализации
            evenBranch.Complete();
            oddBranch.Complete();
            await Task.WhenAll(evenBranch.Completion, oddBranch.Completion);
            sinkBlock.Complete();
            await sinkBlock.Completion;
        }

        return new PipelineHandle<int>
        {
            Input = inputBuffer,
            Completion = CompleteWhenDone(),
            GetProcessedCount = () => processedCount
        };
    }

    // =============================================================
    // 3. ПАЙПЛАЙН С РАССЫЛКОЙ (BROADCAST)
    // =============================================================

    /// <summary>
    /// Пайплайн с рассылкой одного сообщения нескольким получателям:
    ///
    ///   [BufferBlock] -> [BroadcastBlock] -> [ActionBlock #1]
    ///                                     -> [ActionBlock #2]
    ///                                     -> [ActionBlock #3]
    ///
    /// BroadcastBlock копирует каждое сообщение всем подписчикам. Полезно,
    /// например, для рыночной цены — она идёт сразу в несколько обработчиков
    /// (логгер, генератор сигналов, дашборд).
    /// </summary>
    public PipelineHandle<int> BuildBroadcastPipeline()
    {
        int processedCount = 0;

        var inputBuffer = new BufferBlock<int>();

        // cloningFunction для int тривиальна (возвращаем само значение).
        var broadcastBlock = new BroadcastBlock<int>(value => value);

        // Три "получателя": каждый увеличивает общий счётчик, чтобы проверить,
        // что все три получили сообщение.
        var receiver1 = new ActionBlock<int>(_ => Interlocked.Increment(ref processedCount));
        var receiver2 = new ActionBlock<int>(_ => Interlocked.Increment(ref processedCount));
        var receiver3 = new ActionBlock<int>(_ => Interlocked.Increment(ref processedCount));

        var propagate = new DataflowLinkOptions { PropagateCompletion = true };

        inputBuffer.LinkTo(broadcastBlock, propagate);
        broadcastBlock.LinkTo(receiver1, propagate);
        broadcastBlock.LinkTo(receiver2, propagate);
        broadcastBlock.LinkTo(receiver3, propagate);

        // Пайплайн завершён, когда закончили все три получателя.
        var pipelineCompletion = Task.WhenAll(
            receiver1.Completion,
            receiver2.Completion,
            receiver3.Completion);

        return new PipelineHandle<int>
        {
            Input = inputBuffer,
            Completion = pipelineCompletion,
            GetProcessedCount = () => processedCount
        };
    }

    // =============================================================
    // 4. ПАЙПЛАЙН С ОГРАНИЧЕНИЕМ (THROTTLING)
    // =============================================================

    /// <summary>
    /// Пайплайн с ограниченным размером буфера (BoundedCapacity).
    /// Если буфер переполнен, Post вернёт false, а SendAsync будет ждать
    /// свободного места — так реализуется backpressure: быстрый продьюсер
    /// не "забивает" медленного консьюмера.
    ///
    /// ВАЖНО: подавать данные в этот пайплайн нужно через SendAsync (с ожиданием),
    /// иначе при переполнении Post молча отбросит сообщения.
    /// </summary>
    public PipelineHandle<int> BuildThrottledPipeline(int maxMessages)
    {
        if (maxMessages <= 0)
            throw new ArgumentOutOfRangeException(nameof(maxMessages));

        int processedCount = 0;

        var blockOptions = new ExecutionDataflowBlockOptions
        {
            BoundedCapacity = maxMessages,
            EnsureOrdered = true // сохраняем порядок сообщений
        };

        var inputBuffer = new BufferBlock<int>(new DataflowBlockOptions
        {
            BoundedCapacity = maxMessages
        });

        // Немного работы, чтобы буфер реально заполнялся и сбрасывался.
        var transformBlock = new TransformBlock<int, int>(item =>
        {
            try
            {
                int result = item;
                for (int i = 0; i < 100; i++)
                    result = (result * 31 + 17) % 1_000_000;
                return result;
            }
            catch
            {
                return 0;
            }
        }, blockOptions);

        var actionBlock = new ActionBlock<int>(_ =>
        {
            Interlocked.Increment(ref processedCount);
        }, blockOptions);

        var linkOptions = new DataflowLinkOptions { PropagateCompletion = true };

        inputBuffer.LinkTo(transformBlock, linkOptions);
        transformBlock.LinkTo(actionBlock, linkOptions);

        return new PipelineHandle<int>
        {
            Input = inputBuffer,
            Completion = actionBlock.Completion,
            GetProcessedCount = () => processedCount
        };
    }

    // =============================================================
    // 5. ПАЙПЛАЙН С "ПРИОРИТЕЗАЦИЕЙ"
    // =============================================================

    /// <summary>
    /// Псевдо-приоритезированный пайплайн.
    ///
    /// В TPL Dataflow нет встроенной приоритезации, поэтому делаем её вручную
    /// через два входных буфера (high/low), связанных с одним приёмником.
    /// Поскольку highPriorityBuffer связан ПЕРВЫМ, при наличии сообщений в обоих
    /// буферах Dataflow отдаёт предпочтение ему. Это "мягкий" приоритет.
    /// </summary>
    public PrioritizedPipelineHandle BuildPrioritizedPipeline()
    {
        int highProcessed = 0;
        int lowProcessed = 0;

        var highPriorityBuffer = new BufferBlock<string>();
        var lowPriorityBuffer = new BufferBlock<string>();

        var sinkBlock = new ActionBlock<string>(message =>
        {
            try
            {
                if (message.StartsWith("HIGH:"))
                    Interlocked.Increment(ref highProcessed);
                else
                    Interlocked.Increment(ref lowProcessed);
            }
            catch
            {
                // Сообщение с некорректным содержимым просто игнорируем.
            }
        });

        // Сначала связываем высокоприоритетный буфер — он "первый в очереди".
        highPriorityBuffer.LinkTo(sinkBlock);
        lowPriorityBuffer.LinkTo(sinkBlock);

        // Завершение: ждём оба буфера, затем закрываем приёмник (оркестрация).
        async Task CompleteWhenDone()
        {
            await Task.WhenAll(highPriorityBuffer.Completion, lowPriorityBuffer.Completion);
            sinkBlock.Complete();
            await sinkBlock.Completion;
        }

        return new PrioritizedPipelineHandle
        {
            HighPriorityInput = highPriorityBuffer,
            LowPriorityInput = lowPriorityBuffer,
            Completion = CompleteWhenDone(),
            GetHighProcessed = () => highProcessed,
            GetLowProcessed = () => lowProcessed
        };
    }

    /// <summary>Handle для приоритезированного пайплайна — два входа вместо одного.</summary>
    public class PrioritizedPipelineHandle
    {
        public required ITargetBlock<string> HighPriorityInput { get; init; }
        public required ITargetBlock<string> LowPriorityInput { get; init; }
        public required Task Completion { get; init; }
        public required Func<int> GetHighProcessed { get; init; }
        public required Func<int> GetLowProcessed { get; init; }
    }
}
